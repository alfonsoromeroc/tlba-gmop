%ExportDatasetToExcel

filename='I3-SKU50-P15-T25-R10-K200.xlsx';
xlswrite(filename,productmax,'DatasetDetails','B2');
xlswrite(filename,finalproducts,'DatasetDetails','B3');
xlswrite(filename,tmax,'DatasetDetails','B4');
xlswrite(filename,r,'DatasetDetails','B5');
xlswrite(filename,kmax,'DatasetDetails','B6');

xlswrite(filename,demand,'Demanda','B2');
xlswrite(filename,strokeOut,'SalidasStroke','B2');
xlswrite(filename,strokeIn,'EntradasStroke','B2');
xlswrite(filename,storageCost,'CostoAlmacenaje','B2');
xlswrite(filename,backlogCost,'CostoFaltante','B2');
xlswrite(filename,strokeCost,'CostoStroke','B2');
xlswrite(filename,strokeSetup,'CostoSetupStroke','B2');
xlswrite(filename,strokeLeadTime,'LeadTimeStroke','B1');
xlswrite(filename,resourceCapacity,'CapacidadRecursos','B2');
xlswrite(filename,requiredCapacity,'CapacidadRequerida','B2');
xlswrite(filename,requiredSetup,'SetupRequerido','B2');
xlswrite(filename,IINIC,'InventarioInicial','B1');
xlswrite(filename,RPROG,'RecepcionesProgramadas','B2');

