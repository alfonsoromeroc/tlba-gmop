%Heuristica Basada en Listas Tabu 

%%%%%%%%% GENERACION DE INSTACIA ALEATORIA  %%%%%%%%%%
%%
%%Numero de SKUs 
%minimo=15;
%maximo=20;
%productmax= floor(minimo + (maximo - minimo).*rand());
productmax=50;
%%
%Numero de Productos Finales
%minimo=3;
%maximo=15;
finalproducts=15 ; %floor(minimo + (maximo - minimo).*rand());
%%
%Numero de Periodos de Planificacion
%minimo=15;
%maximo=30;
tmax=25; %floor(minimo + (maximo - minimo).*rand());
%%
%Numero de Recursos
%minimo=3;
%maximo=5;
r=10; %floor(minimo + (maximo - minimo).*rand());
%%
%Numero de Strokes
%minimo=20;
%maximo=50;
k=100; %floor(minimo + (maximo - minimo).*rand());
kmax=k;
%%
%Demanda
minimo=1000;
maximo=2000;
demand(productmax,tmax)=zeros();
X(finalproducts,1)=zeros();
a=0;
while a<finalproducts
    productofinal= round(1 + (productmax-1).*rand());
    W= find(X==productofinal);
    Y= isempty(W);
        if Y==1 
            a=a+1;
            pedidos= round((tmax/2) + (tmax-(tmax/2).*rand()));
            for b=1:pedidos
            periodo= round(7 + (tmax-7).*rand());
            demand(productofinal,periodo)= round(minimo + (maximo - minimo).*rand());
            end
            X(a,1)= productofinal;
            else
            end
end
  
%%
%Costo de Almacenamiento
minimo=10;
maximo=20;
storageCost(productmax,tmax)= zeros();
for a=1:productmax
storageCost(a,:) = round(minimo + (maximo - minimo).*rand());
end

%%
%Costo de Operacion del Stroke
strokeCost(kmax,tmax)= zeros();
minimo=5;
maximo=8;
for a=1:kmax
strokeCost(a,:) = round(minimo + (maximo - minimo).*rand());
end

%Costo de Faltantes 
backlogCost(productmax,tmax)=zeros();
minimo=1;
maximo=10;
randcost=round(minimo + (maximo - minimo).*rand());
backlogCost(:,:)=randcost;


%%
%Costo de Setup del Stroke
strokeSetup(k,tmax)= zeros();
minimo=5;
maximo=10;

for a=1:kmax
strokeSetup(a,:) = round(minimo + (maximo - minimo).*rand());
end


%%
%Salidas Strokes
minimo=35;
maximo=50;
strokeOut(productmax,k)= zeros();
for i=1:kmax
    %Cuantos productos de salida tiene el stroke i
    productin= round(1 + (5 - 1).*rand());
    for j=1: productin
        randp= round(1 + (productmax - 1).*rand());
        strokeOut(randp,i)= round(minimo + (maximo - minimo).*rand());
    end
end

%%
%Entradas Strokes
minimo=4;
maximo=8;
strokeIn(productmax,k)=zeros();
for i=1:k
    %Cuantos productos entran al stroke
    prod= ceil(1 + (5 - 1).*rand());
    for j=1:prod
        randp= round(1 + (productmax - 1).*rand());
        strokeIn(randp,i)= floor(minimo + (maximo - minimo).*rand());
    end
end

%%
%Se asegura que cada Stroke tenga por lo menos una entrada.

for i=1:kmax
    if sum(strokeIn(:,i))== 0
    minimo=4;
    maximo=8;
    randp= ceil(1 + (productmax- 1).*rand());
    strokeIn(randp,i)= round(minimo + (maximo - minimo).*rand());
    end
end
%%
%Se impide que los productos finales sean SKU entrantes. 
for i=1:finalproducts
    m= X(i);
  strokeIn(m,:)=0;
 end
%%
%Se impide que los SKU que entren a un Stroke sean los mismos que salgan

h= [strokeIn]==0;
strokeOut = strokeOut.*h;
%%
%Se asegura que cada SKU tenga por lo menos un stroke asignado.

for i=1:productmax
    if sum(strokeOut(i,:))== 0
    minimo=35;
    maximo=50;
    randk= ceil(1 + (kmax- 1).*rand());
    strokeOut(i,randk)= round(minimo + (maximo - minimo).*rand());
    end
end


%%
%LeadTime Strokes
minimo=1;
maximo=2;
strokeLeadTime= round(minimo + (maximo - minimo).*rand(k,1));
%%
%Capacidad de los Recursos
minimo=12000;
maximo=14000;
resourceCapacity(r,tmax)=zeros();
for i=1:r
    resourceCapacity(i,:) = round(minimo + (maximo - minimo).*rand());
end
%%
%Capacidad requerida por los strokes
minimo=2;
maximo=5;
requiredCapacity(k,r) = zeros();
for i=1:kmax
    %Cuantos recursos usa el stroke
    Q(r)=zeros;
    a=0;
    ResourcesToUse=1; %round(1 + (r - 1).*rand());
    while a < ResourcesToUse
        ResourceUsed= round(0 + (r - 0).*rand());
        W= find(Q==ResourceUsed);
        Y= isempty(W);
        if Y==1
          a=a+1;
          Q(a)= ResourceUsed;
          requiredCapacity(i,ResourceUsed) = round(minimo + (maximo - minimo).*rand());
        else
                     
        end
        
    end
   
end

%%
%Tiempos de Setup de los Strokes
minimo=5;
maximo=10;
requiredSetup = floor(minimo + (maximo - minimo).*rand(k,r));
%%
M=5000;
%%
%Estructura MRP
 IINIC(productmax,1)= zeros(); %INVENTARIO INICIAL (i)
 RC(productmax,tmax)= zeros();%REQUERIMIENTOS EN CONJUNTO RC(i,t)
 RPROG(productmax,tmax)= zeros(); %RECEPCIONES PROGRAMADAS OP(i,t)
 BINV(productmax,tmax)= zeros(); %BALANCE DE INVENTARIO BINV(i,t)
 REQNETOS(productmax,tmax)= zeros(); %REQUERIMIENTOS NETOS  REQNETOS(i,t)
 RPLAN(productmax,tmax)= zeros();%RECEPCIONES PLANEADAS   RECP(i,t)
 LIBORD(productmax,tmax)= zeros();%LIBERACI�N DE ORDENES  LIBORD(i,t)
 %%
 %Consumo de Capacidad
 
 consumo(r,tmax)= zeros();
 
  %Solucion Inicial
 
 SolStrokes(k, tmax)= zeros(); 
 Strokes(k, tmax)= zeros();
 %%
%Listado de Productos con demanda Independiente. 
%ReqSKU(SKU) identifica los SKU finales que tienen demanda.
ReqSKU(productmax,1) = zeros();
 
for i=1:productmax
    for j=1:tmax
        if  demand(i,j)>0
            ReqSKU(i,1)= 1;
            continue
        else
        end
    end
end
kc=1; 
SKUCounter=0;
%%
%Crea el listado de los SKU finales que se demandan. 
for i=1:productmax
    if ReqSKU(i,1)>0
        ListadoSKU(kc,1)=i;
        SKUCounter=SKUCounter+1;
        kc=kc+1;
    end
end
%%
%Creaci�n del listado de Entradas para cada Stroke
%StrokeInputs(Stroke,SKU) identifica qu� SKUs entran a cada Stroke
StrokeInputs(kmax,productmax)= zeros();
kmaxc=1;
MaxInputs=0;
for j=1:kmax
    kc=1;
    for i=1:productmax
        if strokeIn(i,j)>0
           StrokeInputs(j,kc)= i;
           if kc>kmaxc
               kmaxc=kc;
               MaxInputs=kmaxc;
           end
            kc=kc+1;
        else
        end
    end
end
%%

%Creaci�n del listado de Salidas para cada Stroke
%StrokeOutputs(Stroke,SKU) identifica qu� SKUs entran a cada Stroke
StrokeOutputs(kmax,productmax)= zeros();
kmaxc=1;
for j=1:kmax
    kc=1;
    for i=1:productmax
        if strokeOut(i,j)>0
           StrokeOutputs(j,kc)= i;
           if kc>kmaxc
               kmaxc=kc;
               MaxOutputs=kmaxc;
           end
            kc=kc+1;
        else
        end
    end
end

%%
% Identifica las alternativas de Stroke para cada SKU
Alt(productmax,kmax)= zeros();
kmaxc=0;
MaxAlt(productmax,1)=zeros();
for i=1:productmax
    if kc>kmaxc
        kmaxc=kc-1;
    end
    kc=1;
    for j=1:k
        if strokeOut(i,j)>0
            Alt(i,kc)= j;
            MaxAlt(i,1)=kc;
            MaxMaxAlt= max(MaxAlt);
            kc=kc+1;
                
        else
        end
    end
end
