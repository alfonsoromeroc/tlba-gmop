%Heuristica basada en listas tab� - Importacion de instancias

%%%%%%%%% CARGA DE DATOS DEL PROBLEMA  %%%%%%%%%%

filename='I7-SKU200-P60-T75-R30-K50.xlsx';
productmax= xlsread(filename,'DatasetDetails','B2');
finalproducts= xlsread(filename,'DatasetDetails','B3');
tmax= xlsread(filename,'DatasetDetails','B4');
r= xlsread(filename,'DatasetDetails','B5');
k= xlsread(filename,'DatasetDetails','B6');
kmax= xlsread(filename,'DatasetDetails','B6');

%Demanda
demand = xlsread(filename,'Demanda');

%Costo de Almacenamiento
storageCost = xlsread(filename,'CostoAlmacenaje');

%Costo de Faltante
backlogCost = xlsread(filename,'CostoFaltante');

%Entradas Strokes
strokeIn = xlsread(filename,'EntradasStroke');

%Salidas Strokes
strokeOut = xlsread(filename,'SalidasStroke');

%Costo Strokes
strokeCost = xlsread(filename,'CostoStroke');

%LeadTime Strokes
strokeLeadTime= xlsread(filename,'LeadTimeStroke');

%Costo Setup Strokes
strokeSetup= xlsread(filename,'CostoSetupStroke');

%Capacidad de los Recursos
resourceCapacity = xlsread(filename,'CapacidadRecursos');

%Capacidad requerida por los strokes
requiredCapacity = xlsread(filename,'CapacidadRequerida');

%Tiempos de Setup de los Strokes
requiredSetup = xlsread(filename,'SetupRequerido');

%Estructura MRP
%INVENTARIO INICIAL (i,0)
IINIC= xlsread(filename,'InventarioInicial'); 
%RECEPCIONES PROGRAMADAS OP(i,t)
RPROG= xlsread(filename,'RecepcionesProgramadas');; 

RC(productmax,tmax)= zeros();%REQUERIMIENTOS EN CONJUNTO RC(i,t)

BINV(productmax,tmax)= zeros(); %BALANCE DE INVENTARIO BINV(i,t)
 REQNETOS(productmax,tmax)= zeros(); %REQUERIMIENTOS NETOS  REQNETOS(i,t)
 RPLAN(productmax,tmax)= zeros();%RECEPCIONES PLANEADAS   RECP(i,t)
 LIBORD(productmax,tmax)= zeros();%LIBERACI�N DE ORDENES  LIBORD(i,t)
 
 %Consumo de Capacidad
 
 consumo(r,tmax)= zeros();
 
 
 %Solucion Inicial
 
 SolStrokes(k, tmax)= zeros();
 Strokes(k, tmax)= zeros();
%Listado de Productos con demanda Independiente. 
%ReqSKU(SKU) identifica los SKU finales que tienen demanda.
ReqSKU(productmax,1) = zeros();
 
for i=1:productmax
    for j=1:tmax
        if  demand(i,j)>0
            ReqSKU(i,1)= 1;
            continue
        else
        end
    end
end
kc=1; 
SKUCounter=0;
%Crea el listado de los SKU finales que se demandan. 
for i=1:productmax
    if ReqSKU(i,1)>0
        ListadoSKU(kc,1)=i;
        SKUCounter=SKUCounter+1;
        kc=kc+1;
    end
end

%Creaci�n del listado de Entradas para cada Stroke
%StrokeInputs(Stroke,SKU) identifica qu� SKUs entran a cada Stroke
StrokeInputs(productmax,kmax)= zeros();
kmaxc=1;
for j=1:kmax
    kc=1;
    for i=1:productmax
        if strokeIn(i,j)>0
           StrokeInputs(j,kc)= i;
           if kc>kmaxc
               kmaxc=kc;
               MaxInputs=kmaxc;
           end
            kc=kc+1;
        else
        end
    end
end

%%

%Creaci�n del listado de Salidas para cada Stroke
%StrokeOutputs(Stroke,SKU) identifica qu� SKUs entran a cada Stroke
StrokeOutputs(kmax,productmax)= zeros();
kmaxc=1;
for j=1:kmax
    kc=1;
    for i=1:productmax
        if strokeOut(i,j)>0
           StrokeOutputs(j,kc)= i;
           if kc>kmaxc
               kmaxc=kc;
               MaxOutputs=kmaxc;
           end
            kc=kc+1;
        else
        end
    end
end

%%
% Identifica las alternativas de Stroke para cada SKU
Alt(productmax,kmax)= zeros();
kmaxc=0;
for i=1:productmax
    if kc>kmaxc
        kmaxc=kc-1;
    end
    kc=1;
    for j=1:k
        if strokeOut(i,j)>0
            Alt(i,kc)= j;
            MaxAlt(i,1)=kc;
            MaxMaxAlt= max(MaxAlt);
            kc=kc+1;
                
        else
        end
    end
end
 