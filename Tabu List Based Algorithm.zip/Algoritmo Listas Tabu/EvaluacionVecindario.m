%Evaluacion de soluciones vecinas
 
 RC(:,:)= zeros();
 BINV(:,:)= zeros(); 
 REQNETOS(:,:)= zeros();
 RPLAN(:,:)= zeros();
 LIBORD(:,:)= zeros();
 CostoTotalInventario=0;
 CostoTotalSetup=0;
 CostoTotalOperacion=0; 
 consumo(:,:)=zeros();
 SolStrokes(:,:)=zeros();

 for i=1:finalproducts
    p= ListadoSKU(i,1);
    RC(p,:)= demand(p,:);
   end

 %/////////////////////////////////////////////%
 %///////////      NIVEL 1          ///////////%
 %/////////////////////////////////////////////%
 %Se realiza el MRP inicial para los productos finales
 for j=1:tmax
     for i=1:finalproducts
         p= ListadoSKU(i,1);
         %display(p)
         z=p;
         TabuMRP;
         
                 
         %Se realiza el MRP para cada producto final. Se define de manera 
         %predeterminada el primer Stroke Alternativo (s).
        
         %Se realiza el MRP para los componentes del primer stroke
         if smrp>0  
             s=AltVec(p,1);
                %display (s) 
                for x=1:MaxInputs
                    y=StrokeInputs(s,x); 
                    if y>0
                    %display (y) 
                        if j>lt
                            RC(y,j-lt)= ceil(RC(y,j-lt)+ ((ceil(RPLAN(p,j)/strokeOut(p,s)))* strokeIn(y,s)));
                            z=y;
                            TabuMRPComponentes;
                        end                     
                    end
               end
         end
      end
 end
 %disp ('NIVEL 2')
 
 %/////////////////////////////////////////////%
 %///////////      NIVEL 2          ///////////%
 %/////////////////////////////////////////////%
 for j=1:tmax
     for i=1:finalproducts
         p= ListadoSKU(i,1);
         %display(p)
         smrp=AltVec(p,1);
         
         if smrp>0  
             s=AltVec(p,1);
                %display (s) 
                for x=1:MaxInputs
                    y=StrokeInputs(s,x); 
                    if y>0
                    %display (y)
                    s2=AltVec(y,1);
                    if s2>0
                        for x2=1:MaxInputs
                        y2=StrokeInputs(s2,x2);
                            if y2>0
                                %display (y2)
                                if j>lt
                                    RC(y2,j-lt)= ceil(RC(y2,j-lt)+ ((ceil(RPLAN(y,j)/strokeOut(y,s2)))* strokeIn(y2,s2)));
                                    z=y2;
                                    TabuMRPComponentes;
                                end  
                            else 
                                continue
                            end
                        end
                    end
                                          
                    end
               end
         end
      end
 end
  
 %disp ('NIVEL 3')
 
 %/////////////////////////////////////////////%
 %///////////      NIVEL 3          ///////////%
 %/////////////////////////////////////////////%
 for j=1:tmax
     for i=1:finalproducts
         p= ListadoSKU(i,1);
         %display(p)
         smrp=AltVec(p,1);
         
         if smrp>0  
             s=AltVec(p,1);
                %display (s) 
                for x=1:MaxInputs
                    y=StrokeInputs(s,x); 
                    if y>0
                    %display (y)
                    s2=AltVec(y,1);
                    if s2>0
                        for x2=1:MaxInputs
                        y2=StrokeInputs(s2,x2);
                            if y2>0
                                %display (y2)
                                s3=AltVec(y2,1);
                                    if s3>0
                                        for x3=1:MaxInputs
                                        y3=StrokeInputs(s3,x3);
                                            if y3>0
                                                %display (y3)
                                                if j>lt
                                                    RC(y3,j-lt)= ceil(RC(y3,j-lt)+ ((ceil(RPLAN(y2,j)/strokeOut(y2,s3)))* strokeIn(y3,s3)));
                                                    z=y3;              
                                                    TabuMRPComponentes;
                                                end  
                                            else 
                                                continue
                                            end
                                        end
                                    end
                            else 
                                continue
                            end
                        end
                    end
                                          
                    end
               end
         end
      end
 end
  
 %Setups
 CostoTotalSetup=0;
 for i=1:kmax
     for j=1:tmax
         if SolStrokes(i,j)>0
         CostoTotalSetup = CostoTotalSetup + strokeSetup(i,j); 
             for w=1:r
                if requiredCapacity(i,r)>0
                   consumo(w,j)= consumo(w,j) + requiredSetup(i,w);
                else
                    continue
                end
             end
         end
     end
 end
 
 %Costo de Inventario
 CostoTotalInventario= sum(sum(BINV.*storageCost))

 
 %Costo de Operacion 
  CostoTotalOperacion= sum(sum(SolStrokes.*strokeCost))
 
  %Costo Total de la Solucion
  
  ZVec =  CostoTotalInventario + CostoTotalSetup + CostoTotalOperacion 