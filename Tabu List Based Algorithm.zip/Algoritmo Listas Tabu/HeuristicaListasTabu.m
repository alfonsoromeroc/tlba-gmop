 %Hueuristica Basada en Listas Tabu%

%Inicializacion
t= 1;
TabuTenure=38; %Tenencia Tabu
TabuTmax=75; %N�mero Maximo de Iteraciones
VecNum=15; %Numero de vecinos encontrados por iteracion
Z0= Z;%Valor Objetivo Inicial
BestSol=Z0; %Mejor Soluci�n = Solucion Inicial
S0= Alt(:,1); %Vector Soluci�n Soluci�n Inicial
S=S0; %Soluci�n Actual
BestSolStrokes(kmax,tmax)=zeros();
BestBINV(productmax,tmax)=zeros();
figure(1);
H=Z;
plot(H);
xlim([1 TabuTmax]);
ylim([1 Z]);
drawnow;



V(productmax,VecNum)= zeros(); %Conjunto de Soluciones Vecinas
RegVec(VecNum,6,TabuTmax)= zeros();
CapacityFit=zeros();
RegBINV(productmax,tmax,(TabuTmax*VecNum))= zeros();
RegSolStrokes(kmax,tmax,(TabuTmax*VecNum))= zeros();
TabuList(kmax,kmax,productmax)= zeros(); %TabuList
RegTime(TabuTmax,2)=zeros();
%ism=0;
%Se configura la diagonal de la lista tabu para impedir que se realicen
%movimientos nulos con el mismo stroke.
for p=1:productmax
    for i=1:kmax
        TabuList(i,i,p)= 9999999;
    end
end
    
registro=1;

while t <= TabuTmax
    
    %Se crea el conjunto de soluciones vecinas V().
    vecinos=1;
    
    while vecinos <= VecNum
    %Se selecciona un producto al azar
    minimo=1; 
    maximo=productmax;
    prod = round(minimo + (maximo - minimo).*rand());
    %Se escoge una de las soluciones vecinas
    if MaxAlt(prod)>=2
        vec= round(1 + (MaxAlt(prod) - 1).*rand());
        %Se verifica si el movimiento es Tabu.
            if TabuList((Alt(prod,vec)),(S(prod)),prod)==0 %Si el movimiento no esta en la lista tabu. 
                %Se incluye en el conjunto de soluciones vecinas.
                %Se registra la informacion de la soluci�n vecina incluida
                   RegVec(vecinos,1,t)= prod;
                   V(:,vecinos)= S;
                   RegVec(vecinos,2,t)= S(prod) ;
                   RegVec(vecinos,3,t)= Alt(prod,vec); 
                   V(prod,vecinos)= Alt(prod,vec); 
                   AltVec(:,1)= V(:,vecinos);
                   RestCap=0;
                   EvaluacionVecindario
                   RegVec(vecinos,4,t)= ZVec;
                   RegVec(vecinos,5,t)=RestCap;
			if RestCap >0
			RegVec(vecinos,4,t)=ZVec+(RestCap*100000)
			end
                   RegBINV(:,:,registro)= BINV;
                   RegSolStrokes(:,:,registro)= SolStrokes;
                   RegVec(vecinos,6,t)= registro;
                   registro=registro+1;
                   vecinos=vecinos+1; 
            else
                
            end
    else
        
    end
            
    end
    
     %Se selecciona la mejor soluci�n del conjunto V
     BestV= min(RegVec(:,4,t));
     
     if BestV<BestSol
         H(t)=BestSol;
         plot(H);
         xlim([1 TabuTmax]);
         ylim([1 Z]);
         drawnow;
     RegTime(t,1)=round(cputime);
     RegTime(t,2)=BestSol;
     [m,i]= min(RegVec(:,4,t));
     CapacityFit= RegVec(i,5,t);
     BestSolStrokes= RegSolStrokes(:,:,RegVec(i,6,t));
     BestBINV= RegBINV(:,:,RegVec(i,6,t));
     %Se actualiza la mejor Soluci�n hasta el momento
     BestSol=BestV;
     %BestSolStrokes=RegSolStrokes(:,:,)
     S=V(:,i);
     %Se actualiza la lista tabu
     X= (TabuList(:,:,:)>0)*-1;
     TabuList(:,:,:) = TabuList(:,:,:)+X;
     %ism=0;               
     %Se agrega el ultimo movimiento realizado a la lista tabu
     TabuList(RegVec(i,2),RegVec(i,3),RegVec(i,1))=TabuTenure;
     TabuList(RegVec(i,3),RegVec(i,2),RegVec(i,1))=TabuTenure;
     t=t+1;
     else
      %Se actualiza la lista tabu
      H(t)=BestSol;
         plot(H);
         xlim([1 TabuTmax]);
         ylim([1 Z]);
         drawnow;
      
      X= (TabuList(:,:,:)>0)*-1;
      TabuList(:,:,:) = TabuList(:,:,:)+X;
      t=t+1;
      %Se cuenta una iteracion sin mejora en el objetivo
      %ism=ism+1;
     end
     
     %if ism>=10
         %disp ('Se detiene por ISM')
         %break
      %end
end

CapacityFit
BestSolStrokes
S
BestSol
%ism



